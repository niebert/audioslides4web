README AudioSlides4Web
----------------------

You can create your own AudioSlides4Web presentation with: 
  URL: https://niebert.github.io/audioslides4web
You can run AudioSlides4Web creator offline as AppLSAC. 


README Image-Folder "Image/"

Copy or replace all of your image in this folder "Image/"

 - /Image/img0.png
 - ...
 - /Image/img13.png




README Audio-Folder "Audio/"

Copy or replace all of your audio in this folder "Audio/"

 - /Audio/audio0.mp3
 - ...
 - /Audio/audio13.mp3

