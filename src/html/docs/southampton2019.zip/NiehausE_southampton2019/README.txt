README Image-Folder "images/"

Copy all of your image files in this folder "images/"

 - /images/img0.png
 - ...
 - /images/img13.png


README Audio-Folder "audio/"

Copy all of your audio files in this folder "audio/"

 - /audio/audio0.mp3
 - ...
 - /audio/audio13.mp3

