README Image-Folder "images/"

Copy all of your image files in this folder "images/"

 - /images/img0.png
 - ...
 - /images/img13.png

